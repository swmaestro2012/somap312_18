//
//  Storm.h
//  Sea
//
//  Created by 박 진 on 12. 10. 9..
//
//

#ifndef __Sea__Storm__
#define __Sea__Storm__

#include <iostream>

#endif /* defined(__Sea__Storm__) */
