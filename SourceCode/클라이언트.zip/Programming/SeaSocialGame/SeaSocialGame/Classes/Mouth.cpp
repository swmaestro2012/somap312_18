//
//  Mouth.cpp
//  SeaSocialGame
//
//  Created by 박 진 on 12. 10. 19..
//
//

#include "Mouth.h"

Mouth::Mouth()
{
    
}

Mouth::~Mouth()
{
    
}