//
//  Environment.h
//  SeaSocialGame
//
//  Created by 박 진 on 12. 11. 17..
//
//

#pragma once

#include <vector>
#include "DecorationInfo.h"

class Environment
{
private:
    
public:
    Environment();
    ~Environment();
};