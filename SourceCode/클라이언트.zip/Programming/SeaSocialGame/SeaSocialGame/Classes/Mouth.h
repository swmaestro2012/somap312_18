//
//  Mouth.h
//  SeaSocialGame
//
//  Created by 박 진 on 12. 10. 19..
//
//

#pragma once

#include "FishPart.h"

class Mouth : public FishPart
{
private:
    
public:
    Mouth();
    ~Mouth();
};