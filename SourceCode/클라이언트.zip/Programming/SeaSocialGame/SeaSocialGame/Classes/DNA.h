//
//  DNA.h
//  Sea
//
//  Created by 박 진 on 12. 10. 9..
//
//

#pragma once

#include "Utility.h"
#include "BodyInfo.h"
#include "FinsInfo.h"
#include "Tag.h"

class DNA
{
private:
    Tag             m_tag;
    
private:
    BodyInfo        *m_pBodyInfo;
    FinsInfo        *m_pFinsInfo;
    EyeInfo         *m_pEyeInfo;
    
    double    m_growCompTime;
    //또 필요한건? 성장 타이머가 있잖아. 그럼 이건 고기와 알 모두에 써먹을순 있어
    //또 지금 상에서 필요한건 뭐 없어?
    //어.. 없어 일단.. 특수효과나 이런것도 있는데 이건 나중에 생각하자
    
public:
    DNA();
    DNA(Tag &tag, BodyInfo *pBodyInfo, FinsInfo *pFinsInfo, EyeInfo *pEyeInfo, double growCompTime);
    DNA(const DNA &dna);
    ~DNA();
    
public:
    inline BodyInfo    *GetBodyInfo()        { return m_pBodyInfo;    }
    inline FinsInfo    *GetFinsInfo()        { return m_pFinsInfo;    }
    inline EyeInfo     *GetEyeInfo()         { return m_pEyeInfo;     }
    inline double      GetGrowCompTime()     { return m_growCompTime; }
    inline Tag         GetTag()              { return m_tag;          }
    
public:
    COLOR_ARGB  GetBodyColor();
    COLOR_ARGB  GetFinsColor();
    COLOR_ARGB  GetEyeColor();
};
