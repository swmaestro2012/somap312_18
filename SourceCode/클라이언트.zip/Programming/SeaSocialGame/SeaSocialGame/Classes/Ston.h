//
//  Ston.h
//  Sea
//
//  Created by 박 진 on 12. 10. 9..
//
//

#ifndef __Sea__Ston__
#define __Sea__Ston__

#include <iostream>

#endif /* defined(__Sea__Ston__) */
