//
//  Ship.h
//  Sea
//
//  Created by 박 진 on 12. 10. 9..
//
//

#ifndef __Sea__Ship__
#define __Sea__Ship__

#include <iostream>

#endif /* defined(__Sea__Ship__) */
