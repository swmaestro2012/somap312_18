//
//  Decoration.h
//  Sea
//
//  Created by 박 진 on 12. 10. 9..
//
//

#ifndef __Sea__Decoration__
#define __Sea__Decoration__

#include <iostream>

#endif /* defined(__Sea__Decoration__) */
