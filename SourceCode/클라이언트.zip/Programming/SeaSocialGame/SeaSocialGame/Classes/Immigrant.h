//
//  Immigrant.h
//  Sea
//
//  Created by 박 진 on 12. 10. 9..
//
//

#ifndef __Sea__Immigrant__
#define __Sea__Immigrant__

#include <iostream>

#endif /* defined(__Sea__Immigrant__) */
